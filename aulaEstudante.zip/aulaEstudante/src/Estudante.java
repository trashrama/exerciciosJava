public class Estudante {
    String nome, matricula, cpf;
    int idade;
}
