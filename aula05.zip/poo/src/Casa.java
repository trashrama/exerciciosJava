public class Casa {
    private String endereco;
    private int portas, janelas;

    // Sempre que eu for criar a classe casa, endereço é obrigatorio
    public Casa(String endereco){
        this.endereco = endereco;
    }

    public Casa(String endereco, int portas, int janelas){
        this.endereco = endereco;
        this.portas = portas;
        this.janelas = janelas;
    }

//    public String retornaEndereco(){
//        return this.endereco; // ou return endereco;
//    }

//    public void addPorta(){ // so pode usar metodos estaticos no proprio arquivo de classe
//        portas++;
//    }
//
//    public void addPorta(int qtd){
//        portas += qtd;
//    }

    // Métodos Modificadores
    public void setPortas(int portas){
        this.portas = portas;
    }
    public void setEndereco(String endereco){
        this.endereco = endereco;
    }


    // Métodos Acessadores

    public int getPortas(){
        return portas;
    }

    public int getJanelas(){
        return this.janelas;
    }
    public String getEndereco() {
        return endereco;
    }
}
