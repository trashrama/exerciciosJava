import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Estoque {

    static Map<String, Produto> estoque = new HashMap<>();
    static Scanner in = new Scanner(System.in);
    static Scanner sc = new Scanner(System.in);

    public void addProduto(Produto prod) {


        if (estoque.containsKey(prod.getNome())) {
            System.out.println("Já existe, substituindo...");
            estoque.get(prod.getNome()).setQtd(estoque.get(prod.getNome()).getQtd()+prod.getQtd());
            return;
        }
        estoque.put(prod.getNome(), prod);
    }

    public void removerProduto(Produto prod) {
        if (estoque.containsKey(prod.getNome())) {
            if (estoque.get(prod.getNome()).getQtd() - prod.getQtd() > 0) {
                estoque.get(prod.getNome()).setQtd(estoque.get(prod.getNome()).getQtd()-prod.getQtd());
                System.out.println("Removido com sucesso!");
                return;
            }

            System.out.println("Não é possível zerar o estoque.");
            return;
        }

        System.out.println("Não está contido na lista.");

    }


    public void verificaEstoque(String nomeProduto) {
        System.out.printf("Estoque de %s: %d\n", nomeProduto, estoque.get(nomeProduto).getQtd());
    }

    public void listarProdutos() {
        estoque.forEach((key, value) -> System.out.println("PRODUTO: " + key + " - " + value.getQtd() + " unid."));
    }

}
