public class testeComparableMain {

    public static void main(String[] args) {
        String s1 = "maria";
        String s2 = "n";

        System.out.println(s1.compareTo(s2));

    }
}
