public class Estudante {

    String nome, matricula, cpf;
    int idade;
    public Estudante(String nome, String matricula, String cpf, int idade) {
        this.nome = nome;
        this.matricula = matricula;
        this.cpf = cpf;
        this.idade = idade;
    }


    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getCpf() {
        return cpf;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getNome() {
        return nome;
    }

    public void printaEstudante(){
        System.out.printf("NOME: %s\n", nome);
        System.out.printf("IDADE: %d\n", idade);
        System.out.printf("MATRICULA: %s\n", matricula);
        System.out.printf("CPF: %s\n", cpf);
        System.out.println();
    }

    // Versão com o ToString (normalmente mais usado)

    public String toString(){
        return "NOME: " + nome + "\n" + "IDADE: " + idade + "\n" + "MATRICULA: " + matricula + "\n" + "CPF: " + cpf + "\n";
    }
}

