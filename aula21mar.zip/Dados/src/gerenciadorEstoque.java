public class gerenciadorEstoque {
}
