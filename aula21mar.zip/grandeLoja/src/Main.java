import java.util.Scanner;

public class Main {

    static Estoque estoque = new Estoque();
    static Scanner in = new Scanner(System.in);
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        int opc, bufInt;
        String bufChar;

        do {
            System.out.println("---- MENU ----");
            System.out.println("[1] - Adicionar Produto");
            System.out.println("[2] - Remover Produto");
            System.out.println("[3] - Consulta por estoque");
            System.out.println("[4] - Listar Produtos");
            System.out.println("[0] - Sair");
            System.out.printf("Digite a sua opção: ");
            opc = in.nextInt();

            switch (opc) {
                case 1:
                    System.out.println("Digite o nome do produto a ser adicionado: ");
                    bufChar = sc.next();
                    System.out.println("Digite a quantidade do produto a ser adicionado");
                    bufInt = in.nextInt();
                    estoque.addProduto(new Produto(bufChar, bufInt));
                    break;
                case 2:
                    System.out.println("Digite o nome do produto a remover quantidade");
                    bufChar = sc.next();
                    System.out.println("Digite a quantidade do produto a ser removida");
                    bufInt = in.nextInt();
                    estoque.removerProduto(new Produto(bufChar, bufInt));
                    break;
                case 3:
                    System.out.println("Digite o nome do produto a verificar no estoque: ");
                    bufChar = sc.next();
                    estoque.verificaEstoque(bufChar);
                    break;
                case 4:
                    estoque.listarProdutos();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida!");
                    break;

            }
        } while (opc != 0);
}
}