// Interface Comparable

public interface Comparable <T>{
    int compareTo(T o);

}
