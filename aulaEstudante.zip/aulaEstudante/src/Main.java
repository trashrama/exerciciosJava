public class Main {
    public static void main(String[] args) {
        Estudante e1 = new Estudante();
        e1.nome = "Carlos";
        e1.cpf = "029.432.765-32";
        e1.matricula = "20121245";
        e1.idade = 15;

        Estudante e2 = new Estudante();
        e2.nome = "Roberto";
        e2.cpf = "021.435.765-49";
        e2.matricula = "20121289";
        e2.idade = 18;

        printaEstudante(e1);
        printaEstudante(e2);
    }

    public static void printaEstudante(Estudante e){
        System.out.printf("NOME: %s\n", e.nome);
        System.out.printf("IDADE: %d\n", e.idade);
        System.out.printf("MATRICULA: %s\n", e.matricula);
        System.out.printf("CPF: %s\n", e.cpf);
        System.out.println();
    }
}