public class Main {
    public static void main(String[] args) {
        // Quatro Pilares

        // Abstração - Representação do Mundo Real
        // Encapsulamento - Esconder dados
        // Herança - Uma classe que herda de outra classe
        // Polimorfismo ..

        Casa casarao = new Casa("Rua C, num 62");

        casarao.setPortas(4);

        Casa mansao = new Casa("Rua Safadeza, num 56");
        mansao.setPortas(15);
        casarao.setEndereco("kkkkkk droga");
        mansao.setEndereco("kkkk esquesi");

        System.out.println(mansao.getEndereco());


        // Regras de Negócio: É o que o cliente pede pra ter no sistema.

        // Modificadores de Acesso:
            // Public: Qualquer classe consegue acessar;
            // Protected: Somente própria classe e suas filhas podem acessar;
            // Private: Somente a própria classe pode acessar;

        // É uma boa prática de programação definir as proproeidades dos atributos como privados


    }


}