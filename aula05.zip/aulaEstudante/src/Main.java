public class Main {
    public static void main(String[] args) {
        Estudante e1 = new Estudante("Carlos", "029.432.765-32", "20121245", 15);
        Estudante e2 = new Estudante("Roberto", "021.435.765-49", "20121289", 18);

        e1.printaEstudante();
        e2.printaEstudante();

        System.out.println(e1.getCpf());

        System.out.println(e1.toString());
    }


}